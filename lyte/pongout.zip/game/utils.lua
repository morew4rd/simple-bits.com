local M = {}

function M.rect_collision(rect1, rect2)
    local h = false
    local v = false
    local vv = 0.
    local vh = 0.
    if rect1.x < rect2.x + rect2.w and
        rect1.x + rect1.w > rect2.x then

        v = true
        vv = math.min((rect1.x + rect1.w - rect2.x), (rect2.x + rect2.w - rect1.x))
    end
    if rect1.y < rect2.y + rect2.h and
        rect1.h + rect1.y > rect2.y then

        h = true
        vh = math.min((rect1.y + rect1.h - rect2.y), (rect2.y + rect2.h - rect1.y))
    end

    return v and h, vh < vv, vh > vv
end

function M.draw_text_centered(str, x, y)
    local w, h = measure_text(str)
    draw_text(str, x - w / 2, y - h / 2)
end

function M.draw_text_rightaligned(str, x, y)
    local w, _h = measure_text(str)
    draw_text(str, x - w, y)
end

return M
