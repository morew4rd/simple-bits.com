local Menu = class()

function Menu:new(title)
    self.title = title or "Menu :)"
    self.choices = {}
    self.current = 1
end

function Menu:choice(name, fn)
    local id = #self.choices+1
    self.choices[id] = { name = name, fn = fn }
    return id
end


function Menu:prev()
    self.current = self.current - 1
    if self.current < 1 then self.current = #self.choices end
end

function Menu:next()
    self.current = self.current - 1
    if self.current > #self.choices then self.current = 1 end
end

function Menu:activate(...)
    return self.choices[self.current].fn(...)
end