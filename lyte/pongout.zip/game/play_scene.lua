local utils = require("game.utils")

local M = {}






function LOG(...)
    -- print(...)
end


BRICK_NUMROWS = 4
BRICK_NUMCOLS = 1
BRICK_DX = 6
BRICK_DY = 10
BRICK_W = 4
BRICK_H = math.floor((CH - 2 * BRICK_DY) / (BRICK_NUMROWS)) - BRICK_DY



local function increase_difficulty()
    if (BRICK_NUMCOLS < 5) then
        BRICK_NUMCOLS = BRICK_NUMCOLS + 1
    end
    if BRICK_NUMROWS < 9 then
        if BRICK_NUMCOLS % 3 == 1 then
            BRICK_NUMROWS = BRICK_NUMROWS + 2
        end
    end

    BRICK_H = math.floor((CH - 2 * BRICK_DY) / (BRICK_NUMROWS)) - BRICK_DY
end

local PaddleLeft = {}

local PaddleRight = {}

local Ball = {}

Bricks = {}

local Walls = {}

increase_difficulty() -- 4 rows
increase_difficulty() -- 4 rows
increase_difficulty() -- 4 rows
increase_difficulty() -- 4 rows
increase_difficulty() -- 4 rows

local function init_walls()
    Walls[1] = { x = 0, y = 0, w = WALL_THICK, h = CH, t = "l" }
    Walls[2] = { x = 0, y = 0, w = CW, h = WALL_THICK }
    Walls[3] = { x = CW - WALL_THICK, y = 0, w = WALL_THICK, h = CH, t = "r" }
    Walls[4] = { x = 0, y = CH - WALL_THICK, w = CW, h = WALL_THICK }
end

function init_bricks()
    local b = 1
    Bricks = {}
    for y = 1, BRICK_NUMROWS do
        for x = 1, BRICK_NUMCOLS do
            Bricks[b] = {
                active = true,
                x = (x - 1) * (BRICK_W + BRICK_DX) + CW / 2 - (BRICK_NUMCOLS * (BRICK_W + BRICK_DX)) / 2,
                y = (y - 1) * (BRICK_H + BRICK_DY) + CH / 2 - (BRICK_NUMROWS * (BRICK_H + BRICK_DY)) / 2,
                w = BRICK_W,
                h = BRICK_H,
                r = 1, g = 1, b = 1,
            }
            -- -- middle "hole"
            if y > BRICK_NUMROWS/2 - 1 and y <= BRICK_NUMROWS/2 + 1 then
                Bricks[b].active = false
            end

            b = b + 1
        end
    end
    play_sound(Assets.sc_brick)
    get_soundvolume(Assets.sc_brick)
end

local function init_paddles_and_ball()
    PaddleLeft.w = 10
    PaddleLeft.h = 30
    PaddleLeft.y = CH / 2 - PaddleLeft.h / 2
    PaddleLeft.x = 10

    PaddleRight.w = 10
    PaddleRight.h = 30
    PaddleRight.y = CH / 2 - PaddleRight.h / 2
    PaddleRight.x = CW - PaddleRight.w - WALL_THICK - 5


    Ball.w = 32 / 4
    Ball.h = 32 / 4
    Ball.vx = 2.0
    Ball.vy = -1.6

    if math.random() > 0.5 then
        Ball.x = PaddleLeft.x + PaddleLeft.w / 2 + Ball.w / 2 + 5
        Ball.y = PaddleLeft.y + PaddleLeft.h / 2. - Ball.h / 2
    else
        Ball.x = PaddleRight.x - PaddleRight.w / 2 - Ball.w / 2 - 5
        Ball.y = PaddleRight.y + PaddleRight.h / 2. - Ball.h / 2
        Ball.vx = Ball.vx * -1
    end

    Ball.x1 = Ball.x
    Ball.y1 = Ball.y



    LOG("PaddleLeft and ball initialized")
end

function M.init()
    init_paddles_and_ball()
    init_walls()
    init_bricks()
end

local function update_paddles(DT)
    local speed = State.paddle_speed * DT
    if is_keydown("f1") then set_musicpitch(1) end
    if is_keydown("f2") then set_musicpitch(1.2) end
    if is_keydown("f3") then set_musicpitch(0.8) end

    if is_keydown("w") or is_gamepaddown(0, "but_dpad_up") then PaddleLeft.y = PaddleLeft.y - speed end
    if is_keydown("s") or is_gamepaddown(0, "but_dpad_down") then PaddleLeft.y = PaddleLeft.y + speed end

    if is_keydown("up") or is_gamepaddown(1, "but_dpad_up") then PaddleRight.y = PaddleRight.y - speed end
    if is_keydown("down") or is_gamepaddown(1, "but_dpad_down") then PaddleRight.y = PaddleRight.y + speed end

    local paddle_delta = 1
    if PaddleLeft.y < 0 + paddle_delta + WALL_THICK then PaddleLeft.y = 0 + paddle_delta + WALL_THICK end
    if PaddleLeft.y >= CH - PaddleLeft.h - paddle_delta - WALL_THICK then PaddleLeft.y = CH - PaddleLeft.h - paddle_delta
        - WALL_THICK end

    if PaddleRight.y < 0 + paddle_delta + WALL_THICK then PaddleRight.y = 0 + paddle_delta + WALL_THICK end
    if PaddleRight.y >= CH - PaddleRight.h - paddle_delta - WALL_THICK then PaddleRight.y = CH - PaddleRight.h -
        paddle_delta - WALL_THICK end
end

local function update_ball(DT)
    -- DT = 1/30
    local speedx = Ball.vx * DT * State.ball_speed
    local speedy = Ball.vy * DT * State.ball_speed
    Ball.x1 = Ball.x
    Ball.y1 = Ball.y
    Ball.x = Ball.x + speedx
    Ball.y = Ball.y + speedy

    local num_bricks_left = 0


    for _, wall in ipairs(Walls) do
        local c, hor, ver = utils.rect_collision(Ball, wall)
        if c then
            LOG("*** wall -- " .. tostring(hor) .. " | " .. tostring(ver))
            Ball.y = Ball.y1
            Ball.x = Ball.x1
            if hor then
                play_sound(Assets.sc_brick)
                Ball.vy = Ball.vy * -1
            end
            if ver then

                if wall.t == "l" then
                    State.right_points = State.right_points + State.lvl_points
                elseif wall.t == "r" then
                    State.left_points = State.left_points + State.lvl_points
                end
                State.lvl_points = 0
                play_sound(Assets.sc_hurt)
                init_paddles_and_ball()
            end
        end
    end


    for _, brick in ipairs(Bricks) do
        if brick.active then
            local c, hor, ver = utils.rect_collision(Ball, brick)
            if c then
                brick.active = false
                State.lvl_points = State.lvl_points + 1
                play_sound(Assets.sc_brick)
                if hor then
                    Ball.y = Ball.y - speedy / 2
                    Ball.vy = Ball.vy * -1
                end
                if ver then
                    Ball.x = Ball.x - speedx / 2
                    Ball.vx = Ball.vx * -1
                end
            else
                num_bricks_left = num_bricks_left + 1
            end
        end
    end



    do
        local c1, hor1, ver1 = utils.rect_collision(Ball, PaddleLeft)
        local c2, hor2, ver2 = utils.rect_collision(Ball, PaddleRight)
        if c1 then
            play_sound(Assets.sc_paddle)
            LOG("+++ paddle_left -- " .. tostring(hor1) .. " | " .. tostring(ver1))
            if hor1 then
                Ball.y = Ball.y - speedy / 2
                Ball.vy = Ball.vy * -1
            end
            if ver1 then
                Ball.x = Ball.x - speedx / 2
                Ball.vx = Ball.vx * -1
            end
        end
        if c2 then
            play_sound(Assets.sc_paddle)
            LOG("+++ paddle_right -- " .. tostring(hor2) .. " | " .. tostring(ver2))
            if hor2 then
                Ball.y = Ball.y - speedy / 2
                Ball.vy = Ball.vy * -1
            end
            if ver2 then
                Ball.x = Ball.x - speedx / 2
                Ball.vx = Ball.vx * -1
            end
        end


    end


    if Ball.x - Ball.w / 2 <= 0 or Ball.x >= CW - Ball.w / 2 then
        Ball.x = Ball.x - 1.5 * Ball.vx * DT * State.ball_speed
        Ball.vx = Ball.vx * -1
    end
    if Ball.y - Ball.h / 2 <= 0 or Ball.y >= CH - Ball.h / 2 then
        Ball.y = Ball.y - 1.5 * Ball.vy * DT * State.ball_speed
        Ball.vy = Ball.vy * -1
    end

    if num_bricks_left == 0 then
        increase_difficulty()
        M.init()
        -- set_scene("menu")
    end

end


local lps = {
    {x=10,y=10},
    {x=10,y=20},
    {x=30,y=50},
    {x=40,y=20},
    {x=50,y=10},
}


function M.update(DT)
    if is_keypressed("escape") then
        set_scene("menu")
        IN_FIRST_MENU = false
    end
    update_paddles(DT)
    update_ball(DT)
end

function M.draw(active)
    clear(0, 0, 0, 1)

    if active then

        set_color(0.9, 0.6, 0.5, 1)
        draw_text("" .. State.left_points, 0 + 2, -TOP_SPACE - 5)
        set_color(0.5, 0.6, 0.9, 1)
        utils.draw_text_rightaligned(State.right_points .. "", CW - 2, -TOP_SPACE - 5)

        set_color(0.4, 0.6, 0.4, 1)
        utils.draw_text_centered(string.rep('|', State.lvl_points), CW / 2, -TOP_SPACE + 14 / 2 - 5)


        set_color(0.9, 0.6, 0.5, 1)
        draw_rect_filled(PaddleLeft.x, PaddleLeft.y, PaddleLeft.w, PaddleLeft.h)


        set_color(0.5, 0.6, 0.9, 1)
        draw_rect_filled(PaddleRight.x, PaddleRight.y, PaddleRight.w, PaddleRight.h)



        set_color(0.8, 0.8, 0.4, 1)
        draw_rect_filled(Ball.x, Ball.y, Ball.w, Ball.h)







        local b = 1
        for y = 1, BRICK_NUMROWS do
            for x = 1, BRICK_NUMCOLS do
                local v = Bricks[b];
                if v then
                    if (v.active) then
                        set_color(v.r, v.g, v.b, 1.0)
                    else
                        set_color(v.r, v.g, v.b, 0.15)
                    end
                    draw_rect_filled(v.x, v.y, v.w, v.h)
                    b = b + 1
                end
            end
        end
    end


    for _, wall in ipairs(Walls) do
        set_color(0.5, 0.6, 0.5, 1)
        draw_rect_filled(wall.x, wall.y, wall.w, wall.h)

    end
    set_color(1,1,0,0.4)
    draw_circle_filled(CW/2-100,CH/2,90)
    -- set_color(1,0,0,0.6)
    draw_circle(CW/2-30,CH/2,12)
    -- set_color(0,1,1,0.6)
    draw_circle(CW/2,CH/2,4)
    -- set_color(1,1,1,1)
    -- draw_striptriangles_filled(lps)

    set_color(1,0,0,1)
    -- draw_points(points)
    -- draw_striplines(points)
    -- draw_striptriangles_filled(points)
    draw_circle(120,40,2)
    -- draw_circle(-110,0,3)
    set_color(1,1,0,1)
    draw_circle(100,40,5)
    set_color(1,0,1,1)
    draw_circle(80,40,10)
    set_color(0,1,1,1)
    -- print("draw circ---")
    draw_circle(130,140,80)
    draw_circle(150,140,120)
    draw_circle(170,140,280)
    -- print("draw circ++")
end

return M
