local Sprite = require("game.sprite")

local Config = {}
Config.W = 380
Config.H = 220
Config.SCALE = 4
Config.pixel_perfect = false
Config.DEBUG = true

set_windowminsize(Config.W,Config.H)
set_windowsize(Config.W*Config.SCALE,Config.H*Config.SCALE)
set_windowtitle("pixel perfect resize")

local Window = {}
Window.width = get_windowwidth()
Window.height = get_windowheight()
Window.canvas = new_canvas(Config.W, Config.H)

local Data = {}
Data.head = Sprite("hero.png", 16, 16, 5, 1)



local function adjust_scale(win_w, win_h)
    Window.width = win_w
    Window.height = win_h
    local sc = math.min(Window.width/Config.W, Window.height/Config.H)
    if Config.pixel_perfect then
        Config.SCALE = math.floor(sc)
    else
        Config.SCALE = sc
    end
end


function frame(dt, win_w, win_h, resized)
    if resized then adjust_scale(win_w, win_h) end

    ------------
    -- update --
    ------------
    Data.head.x = Config.W/2
    Data.head.y = Config.H/2

    -----------
    -- draw --
    -----------
    set_canvas(Window.canvas)

    push_matrix()
    clear(0,0,0,1)
    if Config.DEBUG then
        set_color(1,1,0,1)
        draw_rect(1,1,Config.W-1, Config.H-1)
        reset_color()
    end
    Data.head:draw()
    pop_matrix()
    reset_canvas()
    -----------
    -- flip --
    -----------
    push_matrix()
    if Config.DEBUG then
        clear(0,0.2, 0.2,1)
    else
        clear(0,0,0,1)
    end
    scale(Config.SCALE, Config.SCALE)
    draw_image(Window.canvas.image, (Window.width/Config.SCALE-Config.W)/2, (Window.height/Config.SCALE-Config.H)/2)
    pop_matrix()
    if Config.DEBUG then
        set_color(1,0,0,1)
        draw_rect(1,1,Window.width-1, Window.height-1)
        reset_color()
    end
end


